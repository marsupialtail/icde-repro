import sqlglot

def dfs(node):
    for k, v in node.iter_expressions():
        dfs(v)
    if isinstance(node, sqlglot.exp.Binary):
        print("bump")
        node.replace(sqlglot.exp.Paren(this = node.copy()))
        print(node.sql())

from sqlglot.dataframe.sql import functions as F
z = ((F.col("a") - 1) * F.col("b")).expression
dfs(z)
print(z.sql())
z = (((F.col("a") - 1) * (F.col("b") + 1)) / (F.col("c") - F.col("d"))).expression
dfs(z)
print(z.sql())
