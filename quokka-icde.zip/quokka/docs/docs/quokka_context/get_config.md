# QuokkaContext.get_config

::: pyquokka.df.QuokkaContext.get_config
