# QuokkaContext.read_parquet

::: pyquokka.df.QuokkaContext.read_parquet
