# QuokkaContext.set_config

::: pyquokka.df.QuokkaContext.set_config
