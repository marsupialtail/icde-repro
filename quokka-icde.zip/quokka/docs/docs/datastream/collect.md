## **DataStream.collect**

::: pyquokka.datastream.DataStream.collect
