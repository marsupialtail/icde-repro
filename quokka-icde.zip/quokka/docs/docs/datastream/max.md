# DataStream.max

::: pyquokka.datastream.DataStream.max
