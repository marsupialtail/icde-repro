# DataStream.count_distinct

::: pyquokka.datastream.DataStream.count_distinct
