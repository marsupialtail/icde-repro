# GroupedDataStream.agg_sql

::: pyquokka.datastream.GroupedDataStream.agg_sql
