# DataStream.gramian

::: pyquokka.datastream.DataStream.gramian
