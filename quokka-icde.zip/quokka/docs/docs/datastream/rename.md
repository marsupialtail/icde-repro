# DataStream.rename

::: pyquokka.datastream.DataStream.rename
