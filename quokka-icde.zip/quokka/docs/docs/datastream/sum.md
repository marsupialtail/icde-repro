# DataStream.sum

::: pyquokka.datastream.DataStream.sum
