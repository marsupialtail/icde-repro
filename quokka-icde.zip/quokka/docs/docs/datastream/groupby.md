# DataStream.groupby

::: pyquokka.datastream.DataStream.groupby
