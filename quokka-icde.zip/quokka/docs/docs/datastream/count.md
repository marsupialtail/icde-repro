# DataStream.count

::: pyquokka.datastream.DataStream.count
