# DataStream.filter

::: pyquokka.datastream.DataStream.filter
