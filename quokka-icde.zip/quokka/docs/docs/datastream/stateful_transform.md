# DataStream.stateful_transform

::: pyquokka.datastream.DataStream.stateful_transform
