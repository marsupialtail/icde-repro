# DataStream.mean

::: pyquokka.datastream.DataStream.mean
