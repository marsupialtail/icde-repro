# DataStream.filter_sql

::: pyquokka.datastream.DataStream.filter_sql
