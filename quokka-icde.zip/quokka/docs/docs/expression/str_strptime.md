# ExprStringNameSpace.strptime

::: pyquokka.expression.ExprStringNameSpace.strptime
