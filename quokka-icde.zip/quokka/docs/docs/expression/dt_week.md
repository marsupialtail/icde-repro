# ExprDateTimeNameSpace.week

::: pyquokka.expression.ExprDateTimeNameSpace.week
