# ExprDateTimeNameSpace.hour

::: pyquokka.expression.ExprDateTimeNameSpace.hour
