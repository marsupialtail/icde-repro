# ExprStringNameSpace.to_lowercase

::: pyquokka.expression.ExprStringNameSpace.to_lowercase
