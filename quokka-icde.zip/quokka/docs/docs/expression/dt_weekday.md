# ExprDateTimeNameSpace.weekday

::: pyquokka.expression.ExprDateTimeNameSpace.weekday
