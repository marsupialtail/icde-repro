# ExprDateTimeNameSpace.offset_by

::: pyquokka.expression.ExprDateTimeNameSpace.offset_by
