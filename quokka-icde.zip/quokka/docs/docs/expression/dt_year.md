# ExprDateTimeNameSpace.year

::: pyquokka.expression.ExprDateTimeNameSpace.year
