# ExprStringNameSpace.length

::: pyquokka.expression.ExprStringNameSpace.length
