# ExprDateTimeNameSpace.second

::: pyquokka.expression.ExprDateTimeNameSpace.second
