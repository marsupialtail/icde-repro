# QuokkaClusterManager

::: pyquokka.utils.QuokkaClusterManager.__init__
