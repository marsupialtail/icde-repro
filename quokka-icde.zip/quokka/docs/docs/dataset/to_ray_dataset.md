# DataSet.to_ray_dataset

::: pyquokka.quokka_dataset.Dataset.to_ray_dataset
