# DataSet.to_arrow_refs

::: pyquokka.quokka_dataset.Dataset.to_arrow_refs
