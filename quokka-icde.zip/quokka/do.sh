#!/bin/bash

# Set the name and description of the security group
GROUP_NAME=random-group
GROUP_DESCRIPTION="Custom security group for Quokka"

# Create the security group
aws ec2 create-security-group --group-name "$GROUP_NAME" --description "$GROUP_DESCRIPTION"

# Get the ID of the security group
GROUP_ID=$(aws ec2 describe-security-groups --group-names "$GROUP_NAME" --query "SecurityGroups[0].GroupId" --output text)
echo $GROUP_ID # write this down!

# Allow some inbound TCP traffic
aws ec2 authorize-security-group-ingress --group-id "$GROUP_ID" --protocol tcp --port 0-65535 --cidr 0.0.0.0/0

# Allow all outbound TCP traffic
aws ec2 authorize-security-group-egress --group-id "$GROUP_ID" --protocol tcp --port 0-65535 --cidr 0.0.0.0/0
