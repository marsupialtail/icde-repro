"""
This is a Quokka TaskGraph API implementation of the TPC-H 12 query. 
"""

import sys
import time
from pyquokka import QuokkaContext
from pyquokka.quokka_runtime import TaskGraph
from pyquokka.executors import SQLAggExecutor, BuildProbeJoinExecutor, DiskBuildProbeJoinExecutor, OutputExecutor
from pyquokka.dataset import InputDiskCSVDataset, InputS3CSVDataset, InputParquetDataset, InputEC2ParquetDataset
import boto3
import pyarrow.compute as compute
from pyquokka.target_info import BroadcastPartitioner, HashPartitioner, TargetInfo, PassThroughPartitioner
from pyquokka.placement_strategy import * 
from pyquokka.utils import LocalCluster, QuokkaClusterManager
import polars
import ray
import sqlglot

manager = QuokkaClusterManager(key_name = "zihengw", key_location = "/home/ziheng/Downloads/zihengw.pem")
manager.start_cluster("arm.json")
cluster = manager.get_cluster_from_json("arm.json")
qc = QuokkaContext(cluster,1,1)
# reader_tag =  "c"
reader_tag = "c6gd.2xlarge"
# joiner_tag = "r6id.2xlarge" # "A4"
joiner_tag = "C15"
task_graph = TaskGraph(qc)

def batch_func(df):
    # df = df.with_columns(((df["o_orderpriority"] == "1-URGENT") | (df["o_orderpriority"] == "2-HIGH")).alias("high"))
    # df = df.with_columns(((df["o_orderpriority"] != "1-URGENT") & (df["o_orderpriority"] != "2-HIGH")).alias("low"))
    # result = df.to_arrow().group_by("l_shipmode").aggregate([("high","sum"), ("low","sum")])
    # return polars.from_arrow(result)
    # return polars.from_dict({"s": len(df)})
    
    return df.select(
        [
            polars.col("l_quantity").sum().alias("sum_qty"),
            polars.col("l_extendedprice").sum().alias("sum_base_price"),
            polars.col("l_discount").sum().alias("sum_disc"),
            polars.col("l_tax").sum().alias("sum_tax"),
            polars.col("l_shipdate").max().alias("max_shipdate"),
            polars.col("l_commitdate").max().alias("max_commitdate"),
            polars.col("l_receiptdate").max().alias("max_receiptdate"),
            polars.col("o_totalprice").sum().alias("sum_charge"),
            polars.col("o_orderdate").max().alias("max_orderdate"),
        ]
    )


if sys.argv[1] == "csv":

    lineitem_csv_reader = InputDiskCSVDataset("/Users/EA/Desktop/Quokka_Research/Test_Datasets/tpc-h-public/lineitem.tbl", header = True, sep = "|", stride=16 * 1024 * 1024)
    orders_csv_reader = InputDiskCSVDataset("/Users/EA/Desktop/Quokka_Research/Test_Datasets/tpc-h-public/orders.tbl", header = True, sep = "|", stride=16 * 1024 * 1024)
    # lineitem_csv_reader = InputS3CSVDataset("tpc-h-csv", lineitem_scheme , key = "lineitem/lineitem.tbl.1", sep="|", stride = 128 * 1024 * 1024)
    # orders_csv_reader = InputS3CSVDataset("tpc-h-csv",  order_scheme , key ="orders/orders.tbl.1",sep="|", stride = 128 * 1024 * 1024)
    lineitem = task_graph.new_input_reader_node(lineitem_csv_reader, stage = -1)
    orders = task_graph.new_input_reader_node(orders_csv_reader)

elif sys.argv[1] == "parquet":
    s3 = boto3.client('s3')
    z = s3.list_objects_v2(Bucket="tpc-h-sf100-parquet", Prefix="lineitem.parquet")
    files = ["tpc-h-sf100-parquet/" + i['Key'] for i in z['Contents'] if i['Key'].endswith(".parquet")]
    #lineitem_parquet_reader = InputEC2ParquetDataset(files,columns=['l_shipdate','l_commitdate','l_shipmode','l_receiptdate','l_orderkey'], filters= [('l_shipmode', 'in', ['SHIP','MAIL']),('l_receiptdate','<',compute.strptime("1995-01-01",format="%Y-%m-%d",unit="s")), ('l_receiptdate','>=',compute.strptime("1994-01-01",format="%Y-%m-%d",unit="s"))])
    lineitem_parquet_reader = InputEC2ParquetDataset(files, filters = [('l_shipmode', 'in', ['SHIP','MAIL'])])
    # lineitem_parquet_reader = InputEC2ParquetDataset(files)
    z = s3.list_objects_v2(Bucket="tpc-h-sf100-parquet", Prefix="orders.parquet")
    files = ["tpc-h-sf100-parquet/" + i['Key'] for i in z['Contents'] if i['Key'].endswith(".parquet")]
    orders_parquet_reader = InputEC2ParquetDataset(files)
    # orders_parquet_reader = InputEC2ParquetDataset(files)
    lineitem = task_graph.new_input_reader_node(lineitem_parquet_reader, stage = 1, placement_strategy = TaggedCustomChannelsStrategy(1, reader_tag))
    orders = task_graph.new_input_reader_node(orders_parquet_reader, stage = 0, placement_strategy = TaggedCustomChannelsStrategy(1, reader_tag))

      

# join_executor = DiskBuildProbeJoinExecutor(left_on="o_orderkey",right_on="l_orderkey")
# join_executor = BuildProbeJoinExecutor(left_on="o_orderkey",right_on="l_orderkey")
# join_executor = DiskBuildProbeJoinExecutor(left_on="l_orderkey",right_on="o_orderkey")
join_executor = BuildProbeJoinExecutor(left_on="l_orderkey",right_on="o_orderkey")

if sys.argv[1] == "csv":
    output_stream = task_graph.new_non_blocking_node({0:orders,1:lineitem},join_executor, 
        source_target_info={0:TargetInfo(partitioner = HashPartitioner("o_orderkey"), 
                                        predicate = None,
                                        projection = ["o_orderkey", "o_totalprice","o_orderdate"],
                                        batch_funcs = []), 
                            1:TargetInfo(partitioner = HashPartitioner("l_orderkey"),
                                        predicate = None,
                                        projection = None,
                                        batch_funcs = [])})
else:
    output_stream = task_graph.new_non_blocking_node({1:orders,0:lineitem},join_executor, stage = 1,
        source_target_info={1:TargetInfo(partitioner = HashPartitioner("o_orderkey"), 
                                        predicate = None,
                                        projection = None,
                                        batch_funcs = []), 
                            0:TargetInfo(partitioner = HashPartitioner("l_orderkey"),
                                        predicate = None,
                                        projection = ["l_orderkey","l_quantity","l_extendedprice","l_discount","l_tax","l_shipdate","l_commitdate","l_receiptdate"],
                                        batch_funcs = [])}, placement_strategy = TaggedCustomChannelsStrategy(1,joiner_tag))

agg_executor = SQLAggExecutor([], None, """
        sum(sum_qty) as sum_qty,
        sum(sum_base_price) as sum_base_price,
        sum(sum_disc) as sum_disc,
        sum(sum_tax) as sum_tax,
        max(max_shipdate) as max_shipdate,
        max(max_commitdate) as max_commitdate,
        max(max_receiptdate) as max_receiptdate,
        sum(sum_charge) as sum_charge,
        max(max_orderdate) as max_orderdate
    """)
# output_executor = OutputExecutor("yugan/testing", format = "parquet", region = "us-west-2")
agged = task_graph.new_blocking_node({0:output_stream},  agg_executor, stage = 1, placement_strategy = SingleChannelStrategy(), 
    source_target_info={0:TargetInfo(
        partitioner = BroadcastPartitioner(),
        predicate = None,
        projection = None,
        batch_funcs = [batch_func]
    )})

# agged = task_graph.new_blocking_node({0:output_stream},  output_executor, placement_strategy = TaggedCustomChannelsStrategy(1, joiner_tag), 
#     source_target_info={0:TargetInfo(
#         partitioner = PassThroughPartitioner(),
#         predicate = None,
#         projection = None,
#         batch_funcs = []
#     )})

task_graph.create()
start = time.time()
task_graph.run()
print("total time ", time.time() - start)

print(ray.get(qc.dataset_manager.to_df.remote(agged)))
