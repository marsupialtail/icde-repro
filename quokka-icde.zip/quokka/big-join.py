"""
This is a Quokka TaskGraph API implementation of the TPC-H 12 query. 
"""

import sys
import time
from pyquokka import QuokkaContext
from pyquokka.quokka_runtime import TaskGraph
from pyquokka.executors import SQLAggExecutor, BuildProbeJoinExecutor, DiskBuildProbeJoinExecutor
from pyquokka.dataset import InputDiskCSVDataset, InputS3CSVDataset, InputParquetDataset, InputEC2ParquetDataset
import boto3
import pyarrow.compute as compute
from pyquokka.target_info import BroadcastPartitioner, HashPartitioner, TargetInfo
from pyquokka.placement_strategy import * 
from pyquokka.utils import LocalCluster, QuokkaClusterManager
import polars
import ray
import sqlglot

manager = QuokkaClusterManager(key_name = "oregon-neurodb", key_location = "/home/ziheng/Downloads/oregon-neurodb.pem")
manager.start_cluster("4_cluster.json")
cluster = manager.get_cluster_from_json("4_cluster.json")
qc = QuokkaContext(cluster, 4, 2)

task_graph = TaskGraph(qc)

s3 = boto3.client('s3')
z = s3.list_objects_v2(Bucket="big-join", Prefix="probe")
files = ["big-join/" + i['Key'] for i in z['Contents'] if i['Key'].endswith(".parquet")]
lineitem_parquet_reader = InputEC2ParquetDataset(files, filters = [('id', '<', 50000000)])
orders_parquet_reader = InputEC2ParquetDataset(files, columns = ["id"])
lineitem = task_graph.new_input_reader_node(lineitem_parquet_reader, stage = -1, placement_strategy = CustomChannelsStrategy(1))
orders = task_graph.new_input_reader_node(orders_parquet_reader, placement_strategy = CustomChannelsStrategy(1))

join_executor = BuildProbeJoinExecutor(left_on="id",right_on="id")
# join_executor = DiskBuildProbeJoinExecutor(left_on="id",right_on="id")

def batch_func(df):
    
    return polars.from_dict({"count": len(df)})

output_stream = task_graph.new_non_blocking_node({0:orders,1:lineitem},join_executor,
    source_target_info={0:TargetInfo(partitioner = HashPartitioner("id"), 
                                    predicate = None,
                                    projection = None,
                                    batch_funcs = []), 
                        1:TargetInfo(partitioner = HashPartitioner("id"),
                                    predicate = None,
                                    projection = None,
                                    batch_funcs = [])}, placement_strategy = CustomChannelsStrategy(1))

agg_executor = SQLAggExecutor([], None, "sum(count) as c")

agged = task_graph.new_blocking_node({0:output_stream},  agg_executor, placement_strategy = SingleChannelStrategy(), 
    source_target_info={0:TargetInfo(
        partitioner = BroadcastPartitioner(),
        predicate = None,
        projection = None,
        batch_funcs = [batch_func]
    )})

task_graph.create()
start = time.time()
task_graph.run()
print("total time ", time.time() - start)

print(ray.get(qc.dataset_manager.to_df.remote(agged)))
