# we are going to stress test our redis lock

import ray
import redis
import random
import pickle
import time

@ray.remote
class Worker:
    def __init__(self, channel_id, coordinator_ip) -> None:
        self.r = redis.Redis(coordinator_ip, 6800)
        
        self.channel_id = channel_id
    
    def alive(self):
        return True

    def execute(self):

        count = 0
        while True:

            if self.r.get("recovery-lock") == b'1':
                print(self.channel_id)
                self.r.sadd("waiting-workers",  self.channel_id)
                while True:
                    time.sleep(0.01)
                    a = random.random()
                    if a > 0.9 and self.channel_id % 2 == 0:
                        ray.actor.exit_actor()
                    if self.r.get("recovery-lock") == b'0':
                        break
            
            time.sleep(1)
            a = random.random()
            print(self.channel_id, a, flush = True)
            if a > 0.6:
                ray.actor.exit_actor()
            time.sleep(self.channel_id)
            count += 1

@ray.remote
class SaneWorker:
    def __init__(self, channel_id, coordinator_ip) -> None:
        self.r = redis.Redis(coordinator_ip, 6800)
        
        self.channel_id = channel_id
    
    def alive(self):
        return True

    def execute(self):

        count = 0
        while True:

            if self.r.get("recovery-lock") == b'1':
                print(self.channel_id)
                self.r.sadd("waiting-workers",  self.channel_id)
                while True:
                    time.sleep(0.01)
                    if self.r.get("recovery-lock") == b'0':
                        break
            
            time.sleep(1)
            a = random.random()
            print(self.channel_id, a, flush = True)
            time.sleep(self.channel_id // 3)
            count += 1

@ray.remote
class Coordinator:
    def __init__(self, workers) -> None:
        self.workers = workers
        self.r = redis.Redis("localhost", 6800)
        self.r.flushall()
    
    def execute(self) -> None:
        execute_handles = {worker : self.workers[worker].execute.remote() for worker in self.workers}
        execute_handles_list = list(execute_handles.values())
        while len(execute_handles_list) > 0:
            try:
                finished, unfinished = ray.wait(execute_handles_list, timeout= 0.1)
                execute_handles_list = unfinished
                ray.get(finished)
            except:

                print("detected failure")
                self.r.set("recovery-lock", 1)

                while True:
                    time.sleep(1)

                    failed_nodes = []
                    alive_nodes = []
                    for worker in execute_handles:
                        try:
                            ray.get(self.workers[worker].alive.remote())
                            alive_nodes.append(worker)
                        except:
                            failed_nodes.append(worker)
                        
                    print("alive", alive_nodes)
                    print("failed", failed_nodes)
                    for failed_node in failed_nodes:
                        ray.kill(self.workers[failed_node])

                    waiting_workers = [int(i) for i in self.r.smembers("waiting-workers")]
                    print(waiting_workers)

                    # this guarantees that at this point, all the alive nodes are waiting. 
                    # note this does not guarantee that during recovery, all the alive nodes will stay alive, which might not be true.
                    # failed nodes will basically be forgotten about the system. 
                    if set(alive_nodes).issubset(set(waiting_workers)):
                        break
                
                print("Recoverying!")
                self.r.set("recovery-lock", 0)
                self.r.delete("waiting-workers")
                execute_handles = {worker: execute_handles[worker] for worker in alive_nodes}
                execute_handles_list = list(execute_handles.values())
            
                    
                    
ray.init(address = 'ray://35.91.42.141:10001')
import numpy as np
N = 20
private_ips = ["172.31.3.97", "172.31.14.125", "172.31.14.103", "172.31.0.25"]
ip_choices = np.random.choice(private_ips, N)
ip_choices1 = ["172.31.3.97" if k!= "172.31.3.97" else "localhost" for k in ip_choices ]

print(ip_choices)
print(ip_choices1)

coordinator = Coordinator.options(num_cpus = 0.001, resources={"node:172.31.3.97": 0.001}).\
    remote({ k : SaneWorker.options(max_concurrency=2, num_cpus = 0.001, resources={"node:" + ip_choices[k]: 0.001}).remote(k, ip_choices1[k]) for k in range(N)})
a = coordinator.execute.remote()
ray.get(a)

# coordinator = Coordinator({ k : Worker.options(max_concurrency=2, num_cpus = 0.001).remote(k) for k in range(10)})
# coordinator.execute()
