import ray
import boto3
import concurrent.futures
import pyarrow.csv as csv
import polars
import math
from collections import deque
from io import BytesIO
from schema import * 

class FakeFile:
    def __init__(self, buffers, last_newline, prefix, end_file):
        self.prefix = prefix
        self.buffers = buffers
        self.closed = False
        self.which_file = 0
        self.file_cursor = 0
        self.last_newline = last_newline 
        self.end = len(buffers[0]) if end_file != 0 else last_newline
        self.is_first_read = True
        self.end_file = end_file

    def read(self, length):
        if self.file_cursor + length < self.end:
            if self.is_first_read:
                self.file_cursor += length - len(self.prefix)
                self.is_first_read = False
                buf = self.prefix + self.buffers[0][:self.file_cursor]
                #print(self.prefix)
                #print(buf[:100])
                return buf
            else:
                self.file_cursor += length
                return self.buffers[self.which_file][self.file_cursor - length: self.file_cursor]
        else:

            buf = self.buffers[self.which_file][self.file_cursor : self.end ]

            if self.which_file == self.end_file:
                self.file_cursor = self.last_newline
            else:
                self.file_cursor = self.file_cursor + length - self.end
                self.which_file += 1
                buf += self.buffers[self.which_file][:self.file_cursor]
                if self.which_file == self.end_file:
                    self.end = self.last_newline
                else:
                    self.end = len(self.buffers[self.which_file])
            return buf

    def get_end(self):
        return self.buffers[self.end_file][self.last_newline: len(self.buffers[self.end_file])]
    
    def seek(self):
        raise NotImplementedError

# this should work for 1 CSV up to multiple
class InputS3CSVDataset:
    def __init__(self, bucket, names = None, prefix = None, key = None, sep=",", stride=2e8, header = False, window = 1024 * 32, columns = None) -> None:
        self.bucket = bucket
        self.prefix = prefix
        self.key = key
        self.num_channels = None
        self.names = names
        self.sep = sep
        self.stride = stride
        self.header = header
        self.columns = columns

        self.window = window
        assert not (names is None and header is False), "if header is False, must supply column names"

        self.length = 0
        self.sample = None

        self.workers = 8
        self.s3 = None
    
    # we need to rethink this whole setting num channels business. For this operator we don't want each node to do redundant work!
    def get_own_state(self, num_channels):
        
        samples = []
        print("intializing CSV reading strategy. This is currently done locally, which might take a while.")
        self.num_channels = num_channels

        s3 = boto3.client('s3')  # needs boto3 client, however it is transient and is not part of own state, so Ray can send this thing! 
        if self.key is not None:
            files = [self.key]
            response = s3.head_object(Bucket=self.bucket, Key=self.key)
            sizes = [response['ContentLength']]
        else:
            if self.prefix is not None:
                z = s3.list_objects_v2(Bucket=self.bucket, Prefix=self.prefix)
                files = z['Contents']
                while 'NextContinuationToken' in z.keys():
                    z = s3.list_objects_v2(
                        Bucket=self.bucket, Prefix=self.prefix, ContinuationToken=z['NextContinuationToken'])
                    files.extend(z['Contents'])
            else:
                z = s3.list_objects_v2(Bucket=self.bucket)
                files = z['Contents']
                while 'NextContinuationToken' in z.keys():
                    z = s3.list_objects_v2(
                        Bucket=self.bucket, ContinuationToken=z['NextContinuationToken'])
                    files.extend(z['Contents'])
            sizes = [i['Size'] for i in files]
            files = [i['Key'] for i in files]

        if self.header:
            resp = s3.get_object(
                Bucket=self.bucket, Key=files[0], Range='bytes={}-{}'.format(0, self.window))['Body'].read()
            first_newline = resp.find(bytes('\n', 'utf-8'))
            if first_newline == -1:
                raise Exception("could not detect the first line break. try setting the window argument to a large number")
            if self.names is None:
                self.names = resp[:first_newline].decode("utf-8").split(",")
            else:
                detected_names = resp[:first_newline].decode("utf-8").split(",")
                if self.names != detected_names:
                    print("Warning, detected column names from header row not the same as supplied column names!")
                    print("Detected", detected_names)
                    print("Supplied", self.names)

        total_size = sum(sizes)
        assert total_size > 0
        size_per_partition = int(self.stride * self.workers)

        partitions = {}
        curr_partition_num = 0

        for curr_file, curr_size in zip(files, sizes):
            num_partitions = math.ceil(curr_size / size_per_partition)
            for i in range(num_partitions):
                partitions[curr_partition_num + i] = (curr_file, i * size_per_partition)
            curr_partition_num += num_partitions
        
        # refinement

        @ray.remote
        def download_range(bucket, file, start_byte, end_byte):
            s3 = boto3.client('s3')
            s3.get_object(Bucket=bucket, Key=file, Range='bytes={}-{}'.format(start_byte, end_byte))['Body'].read()
            last_newline = resp.rfind(b'\n')
            return resp[last_newline + 1:]

        for partition in partitions:
            curr_file, start_byte = partitions[partition]
            if start_byte == 0:
                partitions[partition] = (curr_file, start_byte, b'')
            else:
                prefix_fut = download_range.remote(self.bucket, files[curr_file], start_byte - self.window, start_byte)
                partitions[partition] = (curr_file, start_byte, prefix_fut)
        
        for partition in partitions:
            curr_file, start_byte, fut = partitions[partition]
            partitions[partition] = (curr_file, start_byte, ray.get(fut))
        
        #assign partitions
        print(curr_partition_num)
        partitions_per_channel = math.ceil(curr_partition_num / num_channels) 
        channel_info = {}
        for channel in range(num_channels):
            channel_info[channel] = [partitions[channel * partitions_per_channel + i] for i in range(partitions_per_channel)\
                if (channel * partitions_per_channel + i) in partitions]

        self.file_sizes = {files[i] : sizes[i] for i in range(len(files))}
        print("initialized CSV reading strategy for ", total_size // 1024 // 1024 // 1024, " GB of CSV")
        return channel_info

    def execute(self, mapper_id, state = None):

        if self.s3 is None:
            self.s3 = boto3.client("s3")
            self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.workers)

        assert self.file_sizes is not None
        
        if state is None:
            raise Exception("Input lineage is now static.")
        else:
            file, pos, prefix = state
                    
        end = self.file_sizes[file]
        
        def download(x):
            
            end_byte = min(pos + x * self.stride + self.stride - 1, end - 1)
            start_byte = pos + x * self.stride
            if start_byte > end_byte:
                return None
            return self.s3.get_object(Bucket=self.bucket, Key= file, Range='bytes={}-{}'.format(start_byte, end_byte))['Body'].read()

        future_to_url = {self.executor.submit(download, x): x for x in range(self.workers)}
        results = {}
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future] 
            data = future.result()
            results[url] = data

        last_file = self.workers - 1

        for z in range(self.workers):
            if results[z] is None:
                last_file = z -1
                break
        
        if last_file == -1:
            raise Exception("something is wrong, try changing the stride")

        last_newline = results[last_file].rfind(bytes('\n', 'utf-8'))

        fake_file = FakeFile(results, last_newline, prefix, last_file)
        bump = csv.read_csv(fake_file, read_options=csv.ReadOptions(column_names=self.names), parse_options=csv.ParseOptions(delimiter=self.sep))
        del fake_file

        bump = bump.select(self.columns) if self.columns is not None else bump

        return None, polars.from_arrow(bump)


executor = InputS3CSVDataset("tpc-h-csv", names = lineitem_scheme, key = "lineitem/lineitem.tbl.1", header = False, window = 1024 * 32)
import time
start = time.time()
executor.get_own_state(16)
print(time.time() - start)

import boto3

# Create an S3 client
s3 = boto3.client('s3')

# Set the name of the S3 bucket and the key (file name) for the file you want to fetch
bucket_name = 'my-bucket'
key = 'my-file.txt'

# Set the byte ranges you want to fetch from the file.
# Each tuple should contain the start and end byte index for the range you want to fetch.
# For example, to fetch the first 100 bytes of the file, you would use the tuple (0, 100).
# To fetch the next 100 bytes of the file, starting at the 101st byte, you would use the tuple (101, 200), and so on.
byte_ranges = [(0, 100), (101, 200), (201, 300)]

# Create a list of S3 batch operations to fetch the specified byte ranges from the file
operations = [{
    'Operation': 'GetObject',
    'Key': key,
    'Range': 'bytes={}-{}'.format(start, end)
} for start, end in byte_ranges]