from pyquokka.executors import * 
import polars
import numpy as np

a = polars.from_dict({"a": range(100), "b": np.random.normal(size=(100,))})
b = polars.from_dict({"a": range(50, 150), "b": np.random.normal(size=(100,))})

for method in ["inner", "left", "semi"]:
    ref = a.join(b, on = "a", how = method).sort("a")
    join_executor = JoinExecutor(on = "a", how = method)
    partial_results = []
    for k in range(10):
        a_batch = a[k * 10 : k * 10 + 10]
        b_batch = b[k * 10 : k * 10 + 10]
        partial_results.append(join_executor.execute([b_batch], 1, 0))
        partial_results.append(join_executor.execute([a_batch], 0, 0))
    partial_results.append(join_executor.done(0))
    partial_results = [k for k in partial_results if k is not None and len(k) > 0]
    result = polars.concat(partial_results).sort("a")
    print((ref - result).sum())

    