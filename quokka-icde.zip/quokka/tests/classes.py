import redis
import time
import ray
import polars

class SimpleDataset:
    def __init__(self, limit) -> None:
        
        self.limit = limit
        self.num_channels = None

    def get_own_state(self, num_channels):
        self.num_channels = num_channels

    def execute(self, channel_id, pos):
        if pos is None:
            pos = channel_id
        time.sleep(0.5)
        if pos + self.num_channels < self.limit:
            print(pos)
            if pos + self.num_channels == 6 and redis.Redis('localhost',port=6800).get("input_already_failed") is None:
                redis.Redis('localhost',port=6800).set("input_already_failed", 1)
                ray.actor.exit_actor()
            return pos + self.num_channels, polars.from_dict({"a":[pos]})
        else:
            print(pos)
            return None, polars.from_dict({"a":[pos]})

class AddExecutor:
    def __init__(self) -> None:
        self.sum = 0
    
    def checkpoint(self, conn, actor_id, channel_id, seq):
        redis.Redis('localhost',port=6800).set("exec-ckpt-" + str(seq), self.sum)
        return 
    
    def restore(self, conn, actor_id, channel_id, seq):
        self.sum = int(redis.Redis('localhost',port=6800).get("exec-ckpt-" + str(seq)))
        return

    def execute(self,batches,stream_id, channel):
        for batch in batches:
            print(batch)
            print(self.sum)
            self.sum += batch['a'][0]
            if batch['a'][0] == 4 and redis.Redis('localhost',port=6800).get("exec_already_failed") is None:
                redis.Redis('localhost',port=6800).set("exec_already_failed", 1)
                ray.actor.exit_actor()

    def done(self,channel):
        print("I am executor ", channel, " my sum is ", self.sum)
        return polars.DataFrame([self.sum])