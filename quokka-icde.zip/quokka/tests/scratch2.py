import sys
sys.path.append("/home/ziheng/new-quokka/")
from quokka_runtime import * 
from target_info import * 
from placement_strategy import * 
from utils import * 
from classes import * 

cluster = LocalCluster()
task_graph = TaskGraph(cluster, 2, 2)

test_reader = SimpleDataset(10)
test_executor = AddExecutor()

reader = task_graph.new_input_reader_node(test_reader)
exec = task_graph.new_blocking_node({0:reader}, test_executor, 
    placement_strategy= SingleChannelStrategy(),
    source_target_info={
        0: TargetInfo(
            partitioner = BroadcastPartitioner(),
            predicate = None,
            projection = None,
            batch_funcs= []
        )
    }
)
task_graph.create()
task_graph.run()
print(exec.to_df())
