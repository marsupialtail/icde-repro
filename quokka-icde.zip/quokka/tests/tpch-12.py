import sys
sys.path.append("/home/ziheng/new-quokka/")
from pyquokka.quokka_runtime import * 
from pyquokka.utils import * 
from pyquokka.dataset import * 
from pyquokka.executors import AggExecutor, JoinExecutor, CountExecutor
from schema import * 

manager = QuokkaClusterManager()
#cluster = LocalCluster()
cluster = manager.get_cluster_from_json("config.json")
task_graph = TaskGraph(cluster, 4, 1)

def batch_func(df):
    df = df.with_column(polars.Series(name = "high", values=((df["o_orderpriority"] == "1-URGENT") | (df["o_orderpriority"] == "2-HIGH"))))
    df = df.with_column(polars.Series(name = "low", values=((df["o_orderpriority"] != "1-URGENT") & (df["o_orderpriority"] != "2-HIGH"))))
    
    result = df.to_arrow().group_by("l_shipmode").aggregate([("high","sum"), ("low","sum")])
    result = polars.from_arrow(result).with_column(polars.lit(1).cast(polars.Int64).alias("__count_sum"))
    return result


if sys.argv[1] == "csv":

    #lineitem_csv_reader = InputDiskCSVDataset("/home/ziheng/tpc-h/lineitem.tbl", header=True, sep = "|", stride=128 * 1024 * 1024)
    #orders_csv_reader = InputDiskCSVDataset("/home/ziheng/tpc-h/orders.tbl", header=True, sep = "|", stride=128 * 1024 * 1024)
    lineitem_csv_reader = InputS3CSVDataset("tpc-h-csv", lineitem_scheme , key = "lineitem/lineitem.tbl.1", sep="|", stride = 128 * 1024 * 1024)
    orders_csv_reader = InputS3CSVDataset("tpc-h-csv",  order_scheme , key ="orders/orders.tbl.1",sep="|", stride = 128 * 1024 * 1024)
    lineitem = task_graph.new_input_reader_node(lineitem_csv_reader)
    orders = task_graph.new_input_reader_node(orders_csv_reader)

elif sys.argv[1] == "parquet":
    lineitem_parquet_reader = InputParquetDataset("tpc-h-parquet","lineitem.parquet",columns=['l_shipdate','l_commitdate','l_shipmode','l_receiptdate','l_orderkey'], filters= [('l_shipmode', 'in', ['SHIP','MAIL']),('l_receiptdate','<',compute.strptime("1995-01-01",format="%Y-%m-%d",unit="s")), ('l_receiptdate','>=',compute.strptime("1994-01-01",format="%Y-%m-%d",unit="s"))])
    orders_parquet_reader = InputParquetDataset("tpc-h-parquet","orders.parquet",columns = ['o_orderkey','o_orderpriority'])
    lineitem = task_graph.new_input_reader_node(lineitem_parquet_reader)
    orders = task_graph.new_input_reader_node(orders_parquet_reader)
      

join_executor = JoinExecutor(left_on="o_orderkey",right_on="l_orderkey")

if sys.argv[1] == "csv":
    output_stream = task_graph.new_non_blocking_node({0:orders,1:lineitem},join_executor,
        source_target_info={0:TargetInfo(partitioner = HashPartitioner("o_orderkey"), 
                                        predicate = None,
                                        projection = ["o_orderkey", "o_orderpriority"],
                                        batch_funcs = []), 
                            1:TargetInfo(partitioner = HashPartitioner("l_orderkey"),
                                        predicate = sqlglot.parse_one("l_shipmode IN ('MAIL','SHIP') and l_commitdate < l_receiptdate and l_shipdate < l_commitdate and \
            l_receiptdate >= date '1994-01-01' and l_receiptdate < date '1995-01-01'"),
                                        projection = ["l_orderkey","l_shipmode"],
                                        batch_funcs = [])})
else:
    output_stream = task_graph.new_non_blocking_node({0:orders,1:lineitem},join_executor,
        source_target_info={0:TargetInfo(partitioner = HashPartitioner("o_orderkey"), 
                                        predicate = None,
                                        projection = None,
                                        batch_funcs = []), 
                            1:TargetInfo(partitioner = HashPartitioner("l_orderkey"),
                                        predicate = sqlglot.parse_one("l_commitdate < l_receiptdate and l_shipdate < l_commitdate "),
                                        projection = ["l_orderkey","l_shipmode"],
                                        batch_funcs = [])})

agg_executor = AggExecutor(["l_shipmode"], None, {"high_sum": "sum", "low_sum":"sum"}, {}, False)

agged = task_graph.new_blocking_node({0:output_stream},  agg_executor, SingleChannelStrategy(), 
    source_target_info={0:TargetInfo(
        partitioner = BroadcastPartitioner(),
        predicate = None,
        projection = None,
        batch_funcs = [batch_func]
    )})
# count_executor = CountExecutor()
# agged = task_graph.new_blocking_node({0:output_stream},  count_executor, SingleChannelStrategy(), 
#     source_target_info={0:TargetInfo(
#         partitioner = BroadcastPartitioner(),
#         predicate = None,
#         projection = None,
#         batch_funcs = []
#     )})

    #1947286

task_graph.create()
start = time.time()
task_graph.run()
print("total time ", time.time() - start)

print(agged.to_df())
