import sys
sys.path.append("/home/ziheng/new-quokka/")
from pyquokka.core import * 
from pyquokka.coordinator import * 
import random
import ray
from classes import * 
from pyquokka.quokka_dataset import ArrowDataset 

ray.init()

r = redis.Redis("localhost",6800, db=0)
r.flushall()

# must be initialized before you instantiate the TaskManagers
CLT = ChannelLocationTable()
CLT.set(r, pickle.dumps((1,0)), "localhost")


io_node = IOTaskManager.options(num_cpus = 0.001, max_concurrency = 2).remote(0, "localhost", ["localhost"])
backup_ionode = IOTaskManager.options(num_cpus = 0.001, max_concurrency = 2).remote(2, "localhost", ["localhost"])
compute_node = ExecTaskManager.options(num_cpus = 0.001, max_concurrency = 2).remote(1, "localhost", ["localhost"])
backup_compute_node = ExecTaskManager.options(num_cpus = 0.001, max_concurrency = 2).remote(3, "localhost", ["localhost"])

ray.get([io_node.init.remote(), backup_ionode.init.remote(), compute_node.init.remote(), backup_compute_node.init.remote()])

simple_dataset = SimpleDataset(10) # actor_id 0
simple_dataset.get_own_state(2)
add_executor = AddExecutor() # actor_id 1

FOT = FunctionObjectTable()
FOT.set(r, 0, ray.cloudpickle.dumps(simple_dataset))
FOT.set(r, 1, ray.cloudpickle.dumps(add_executor))

b = io_node.register_partition_function.remote(0, 1, 1, lambda x, y: {0:x})
c = backup_ionode.register_partition_function.remote(0, 1, 1, lambda x, y: {0:x})
ray.get([b, c])

b = backup_compute_node.register_mapping.remote(1,{0:0}) # shouldn't be necessary
e = compute_node.register_mapping.remote(1,{0:0}) # shouldn't be necessary
ray.get([b,e])

dataset = ArrowDataset.remote(1)
b = backup_compute_node.register_blocking.remote(1, dataset) # shouldn't be necessary
e = compute_node.register_blocking.remote(1, dataset) # shouldn't be necessary
ray.get([b,e])

coordinator_node = Coordinator.remote()
a = coordinator_node.register_nodes.remote(io_nodes = {0: io_node, 2:backup_ionode}, compute_nodes = {1:compute_node, 3:backup_compute_node})
b = coordinator_node.register_node_ips.remote({0: "localhost", 1:"localhost", 2:"localhost", 3:"localhost"})
c = coordinator_node.register_actor_location.remote(0, {0: 0, 1: 0})
d = coordinator_node.register_actor_location.remote(1, {0: 1})
e = coordinator_node.register_actor_topo.remote([1])
ray.get([a,b,c,d,e])

# actor_id, channel_id, seq, input_argument
input_task = InputTask(0, 0, 0, 0)
input_task2 = InputTask(0, 1, 0, 1)
input_reqs = polars.from_dict({"source_actor_id":[0,0], "source_channel_id":[0,1], "min_seq":[0,0]})
exec_task = ExecutorTask(1, 0, 0, 0, input_reqs)
IRT = InputRequirementsTable
IRT.set(r, pickle.dumps((1,0,-1)), pickle.dumps(input_reqs))

NTT = NodeTaskTable()
NTT.rpush(r, str(0), input_task.reduce())
NTT.rpush(r, str(2), input_task2.reduce())
NTT.rpush(r, str(1), exec_task.reduce())

c = coordinator_node.execute.remote()
ray.get([c])

print(ray.get(dataset.to_df.remote()))
