def test1():
    d = lineitem.join(orders,left_on="l_orderkey", right_on="o_orderkey")
    d = customer.join(d,left_on="c_custkey", right_on="o_custkey")

    d = d.filter("l_commitdate < l_receiptdate")
    d = d.filter("l_commitdate > l_shipdate")
    d = d.filter("o_clerk > o_comment")
    d = d.filter("l_tax >o_totalprice")

    d = d.select(["l_commitdate", "o_clerk", "c_name"])
    d.collect()

def self_join_test():
    
    f = lineitem.join(lineitem,on="l_orderkey",suffix="_2")
    d = f.filter("l_commitdate < l_receiptdate")

    d.collect()


def suffix_test():
    d = join(testa,testb, on="key")
    d = d.filter(d.val1 > d.val1_2)
    d = d.filter(d.val2_2 > d.val3_2)
    d = d.filter(d.val1_2 == d.val3_2)
    d = d.filter(d.val1 > d.val2)
    d = d.compute()
    sql.__push_filter__(d)
    d.walk()
