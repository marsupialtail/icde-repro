from pyquokka.df import * 
qc = QuokkaContext()
disk_path = "/home/ziheng/Downloads/sarah-tpch/"
lineitem = qc.read_csv(disk_path + "lineitem.tbl", sep="|", has_header=True).drop(["null"])
d = lineitem.approximate_quantile(["l_tax"], 0.9)
print(d.collect())
